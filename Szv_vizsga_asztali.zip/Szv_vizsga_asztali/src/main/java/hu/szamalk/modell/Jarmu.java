package hu.szamalk.modell;

public class Jarmu {

    private String rendszam;
    private Minosites minosites;

    public Jarmu(String rendszam, Minosites minosites) {
        this.rendszam = rendszam;
        this.minosites = minosites;
    }

    public Minosites getMinosites() {
        return minosites;
    }

    public String getRendszam() {
        return rendszam;
    }

    public void setRendszam(String rendszam) {
       if(getRendszam().contains("-")== false) {
           throw new RendszamException("Nem tartalmaz kötőjelet!");
       }
       this.rendszam = rendszam;
    }

    @Override
    public String toString() {
        return "Jarmu{" +
                "rendszam='" + rendszam + '\'' +
                ", minosites=" + minosites +
                '}';
    }

    //
//    public int compareTo(Auto o) {
//        return 0;
//    }
}
