package hu.szamalk.modell;

public enum Minosites {
    KIVALLO, ATLAGOS,MEGFELELO;
}
