package hu.szamalk.modell;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Kolcsonzo {
    private ArrayList<Jarmu> jarmuvek;

    public Kolcsonzo() {
        jarmuvek = new ArrayList<>();
        jarmuvek.add(new Auto("abc-123",Minosites.KIVALLO, UUID.randomUUID(),"kedd"));
        jarmuvek.add(new Auto("abc-123",Minosites.ATLAGOS, UUID.randomUUID()));
        jarmuvek.add(new Hajo("abc-123",Minosites.KIVALLO, "Titanic", 2000));
        jarmuvek.add(new Hajo("abc-123",Minosites.MEGFELELO, "Jancsi", 3));

        System.out.println("A kölcsönző jarmuvei:" + jarmuvek);
    }

    public List<Jarmu> getJarmuvek() {
        return jarmuvek;
    }
}
