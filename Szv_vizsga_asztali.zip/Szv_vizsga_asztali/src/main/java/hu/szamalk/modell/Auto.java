package hu.szamalk.modell;

import java.text.Collator;
import java.util.UUID;

public class Auto extends Jarmu{
    private UUID azon;
    private String berlesNap;


    public Auto(String rendszam, Minosites minosites,UUID azon) {
        super(rendszam, minosites);
        this.azon = azon;
        this.berlesNap = "hétfő";
    }

    public Auto(String rendszam, Minosites minosites, UUID azon, String berlesNap) {
        super(rendszam, minosites);
        this.azon = azon;
        this.berlesNap = berlesNap;
    }

    @Override
    public String toString() {
        return
                super.toString() + "Auto{" +
                "azon=" + azon +
                ", berlesNap='" + berlesNap + '\'' +
                '}';
    }


    //    @Override
//    public int compareTo(Auto o) {
//        return this.getRendszam().compareTo(o.getRendszam());
//    }
}
