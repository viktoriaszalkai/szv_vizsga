package hu.szamalk.modell;

public class RendszamException extends RuntimeException{
    public RendszamException(String uzenet){
        super(uzenet);
    }
}
