package hu.szamalk.modell;

public class Hajo extends Jarmu{

    private String nev;
    private int hanyFo;

    public Hajo(String rendszam, Minosites minosites, String nev, int hanyFo) {
        super(rendszam, minosites);
        this.nev = nev;
        this.hanyFo = hanyFo;
    }

    @Override
    public String toString() {
        return super.toString() + "Hajo{" +
                "nev='" + nev + '\'' +
                ", hanyFo=" + hanyFo +
                '}';
    }
}
