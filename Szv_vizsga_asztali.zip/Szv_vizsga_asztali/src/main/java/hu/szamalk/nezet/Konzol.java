package hu.szamalk.nezet;

import hu.szamalk.modell.Auto;
import hu.szamalk.modell.Hajo;
import hu.szamalk.modell.Jarmu;
import hu.szamalk.modell.Kolcsonzo;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Konzol implements Serializable {
Kolcsonzo k = new Kolcsonzo();

    public void jarmuvekKonzolon() {

    }

    public void jarmuvekFajlban() {
        try(ObjectOutputStream objKi = new ObjectOutputStream(new FileOutputStream("jarmuvek.ser"))){
            for(Jarmu jarmu:k.getJarmuvek()){
                objKi.write(jarmu);
            }catch(FileNotFoundException){
                throw new RuntimeException()
            }


        }
    }
}
