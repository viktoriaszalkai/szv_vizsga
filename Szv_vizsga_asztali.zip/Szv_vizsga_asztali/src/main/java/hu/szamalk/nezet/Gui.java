package hu.szamalk.nezet;

import hu.szamalk.modell.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.UUID;

public class Gui {
    private JPanel pnlMain;
    private JTextField txtfKolcsonzes;
    private JButton btnAtmozgat;
    private JButton btnAtmasol;
    private JComboBox cmbJarmuvek;
    private JList listKolcsonztesek;
    private JFrame frame;
    private JMenuItem mitBeolvas,mitKilepes;
    private JMenu mnuPrg;
    public Auto auto = new Auto("abc-123",Minosites.KIVALLO, UUID.randomUUID(),"kedd");
    public Hajo hajo = new Hajo("abc-123",Minosites.KIVALLO, "Titanic", 2000);
    public Gui() {
        ini();
        mitBeolvas = new JMenuItem("Mentés");
        mitKilepes = new JMenuItem("Kilépés");
        JMenu mnuPrg = new JMenu("Program");
        mnuPrg.add(mitBeolvas);
        mnuPrg.add(new JSeparator());
        mnuPrg.add(mitKilepes);
        JMenuBar mnuBar = new JMenuBar();
        mnuBar.add(mnuPrg);
        frame.setVisible(true);
        frame.pack();


        mitKilepes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kilepes();
            }
        });

        frame.addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {
                kilepes();
            }

            @Override
            public void windowClosing(WindowEvent e) {

            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });

        mitBeolvas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser jfc = new JFileChooser(new File(System.getProperty("jarmu.dir")));
                if(jfc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
                    File fajl = jfc.getSelectedFile();
                }try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fajl))){
                    Kolcsonzo modell = (Kolcsonzo) ois.readObject();
                    btnAtmozgat.setSelected();

                }

            }

        });


    }

    private void ini(){
        frame = new JFrame("Vizsga");
        frame.setContentPane(pnlMain);
        frame.setSize(520,240);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.setLocationRelativeTo(null);


    }

    private void kilepes(){
        String msg = "Biztos Kilépsz?";
        String cim = "KILÉPÉS!";
        int opt = JOptionPane.OK_CANCEL_OPTION;
        int gomb = JOptionPane.showConfirmDialog(null, msg,cim,opt);
        if(gomb == JOptionPane.OK_OPTION){
            System.exit(0);
        }
    }
}
