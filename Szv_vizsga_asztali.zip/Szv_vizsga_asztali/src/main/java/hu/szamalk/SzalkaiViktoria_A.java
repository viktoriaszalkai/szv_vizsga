package hu.szamalk;

import hu.szamalk.modell.Kolcsonzo;
import hu.szamalk.nezet.Gui;
import hu.szamalk.nezet.Konzol;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class SzalkaiViktoria_A {
    public static void main(String[] args) {
//        Konzol k = new Konzol();
        Gui g = new Gui();
    }
}