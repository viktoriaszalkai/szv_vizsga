import logo from './logo.svg';
import './App.css';
import React from 'react';
import Szotar from './components/szotar.js'

function App() {
  return (
    <div className="App">
    <h2> Szótár</h2>
    <h1>Szavak</h1>
    <Szotar/>
    </div>
  );
}

export default App;
