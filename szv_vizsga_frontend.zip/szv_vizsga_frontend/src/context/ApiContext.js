import { createContext,React, useContext, useEffect, useState } from "react";
import { myAxios } from "../MyAxios/myAxios";

const ApiContext = createContext();

export const ApiProvider = ({children}) =>{
const[szavak,setSzavak] = useState([]);
const[temak,setTemak] = useState([]);

const getSzavak = async(vegpont)=>{
    try{
        const adat = await myAxios.get(vegpont);
        setSzavak(adat.data);
/*         console.log(adat);
 */    }catch(error){
/*         console.log(error,error.response?.adat)
 */    }
}

const getTema = async(vegpont)=>{
    try{
        const adat = await myAxios.get(vegpont);
        setTemak(adat.data);
        console.log(adat.data);
    }catch(error){
/*         console.log(error,error.response?.adat)
 */    }
}

useEffect(()=>{
    getSzavak("http://localhost:8000/api/szavak")
    getTema("http://localhost:8000/api/tema")

})


return(
    <ApiContext.Provider value = {{
        setSzavak,setTemak,szavak,temak
    }}
    >
        {children}
    </ApiContext.Provider>
);
};

export default ApiContext;