import axios from 'axios';


export const myAxios=axios.create({
    baseUrl:"http://localhost:8000",
    timeout:30000,
    withCredentials:false,
});