import React from "react";

function Sor(props){
    const visszajelzes = "X";
    const handleClick=(e)=>{
        e.preventDefault();
        
        if(e.target.value = props.adat.magyar){
                visszajelzes = "pipa";
            }
       
    }
    return(
        <div className="sor">
            <div className="sorElem">
            <h2>
                ANGOL
            </h2>
            <p>
            {props.adat.angol}
            </p>
            </div>
            <div className="sorElem">
            <h2>
                MAGYAR
            </h2>
    
            <select className="tema"  onChange={(e)=> handleClick(e.target.value)}>
            <option>{props.adat.magyar}</option>
            <option>{props.adat.magyar}</option>
            </select>
        
            </div>
            <div className="sorElem">
            <h2>
                visszajelzés
            </h2>
            <p>
            {visszajelzes}
            </p>
            </div>
        </div>
    )
}

export default Sor;