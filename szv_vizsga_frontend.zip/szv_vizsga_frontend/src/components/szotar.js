import { React, useActionState, useContext, useEffect } from "react";
import ApiContext from "../context/ApiContext.js";
import Sor from "./sor.js";
import useApiContext from "../context/ApiContext.js";

function Szotar() {
  const { szavak,temak } = useContext(ApiContext);

  return (
    <div>
      <select className="tema">
        {/* <option>{temak.data.temanev}</option>
        <option>{temak.data.temanev}</option> */}
        <option>állatok</option>
        <option>gyümölcsök</option>
      </select>
      
      {szavak.map((szo, index) => {
        return <Sor adat={szo} key={index} />;
      })}
    </div>
  );
}

export default Szotar;
